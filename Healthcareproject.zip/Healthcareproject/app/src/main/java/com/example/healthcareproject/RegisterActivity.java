package com.example.healthcareproject;

import android.os.Bundle;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

import android.widget.TextView;
public class RegisterActivity extends AppCompatActivity {
    EditText editTextRegUsername, editTextRegPassword,editTextRegEmail, editTextRegConfirmPassword;
    Button btnRegister;
    TextView tvExistUser, tvRegistration, tvHealth ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        editTextRegUsername=findViewById(R.id.editTextRegUsername);
        editTextRegPassword=findViewById(R.id.editTextRegPassword);
        editTextRegConfirmPassword=findViewById(R.id.editTextRegConfirmPassword);
        editTextRegEmail=findViewById(R.id.editTextRegEmail);
        btnRegister=findViewById(R.id.btnRegister);
        tvExistUser=findViewById(R.id.tvExistUser);
        tvHealth=findViewById(R.id.tvHealth);
        tvRegistration=findViewById(R.id.tvRegistration);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username=editTextRegUsername.getText().toString();
                String password=editTextRegPassword.getText().toString();
                String email=editTextRegEmail.getText().toString();
                String confirm=editTextRegConfirmPassword.getText().toString();
                Database db=new Database(getApplicationContext(),"healthcare",null,1);
                if(username.isEmpty() || password.isEmpty() || email.isEmpty() || confirm.isEmpty())
                {
                    Toast.makeText(getApplicationContext(),"All Fields are required!",Toast.LENGTH_SHORT).show();
                }
                else {
                    if(password.compareTo(confirm)==0){
                        if(isValid(password))
                        {
                            db.register(username,email,password);
                            Toast.makeText(getApplicationContext(), "Record successfully!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
                        }
                        else{
                            Toast.makeText(getApplicationContext(), "password must contain 8 characters.", Toast.LENGTH_SHORT).show();
                        }

                    }
                    else {
                        Toast.makeText(getApplicationContext(), "password does not match.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
    public static boolean isValid(String passwordhere)
    {
        int f1=0,f2=0,f3=0;
        if(passwordhere.length()<8)
        {
            return false;
        }
        else{
            for(int p=0;p<passwordhere.length();p++)
            {
                if(Character.isLetter(passwordhere.charAt(p)))
                {
                    f1=1;
                }
            }
            for(int r=0;r<passwordhere.length();r++)
            {
                if(Character.isDigit(passwordhere.charAt(r)))
                {
                    f2=1;
                }
            }
            for(int s=0;s<passwordhere.length();s++)
            {
                char c=passwordhere.charAt(s);
                if(c>=33&&c<=46||c==64)
                {
                    f3=1;
                }
            }
            if(f1==1&&f2==1&&f3==1)
            {
                return true;
            }
            else{
                return false;
            }
        }
    }
}