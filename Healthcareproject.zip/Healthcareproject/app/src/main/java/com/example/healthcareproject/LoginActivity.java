package com.example.healthcareproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

import android.widget.TextView;


public class LoginActivity extends AppCompatActivity {

    EditText editTextLoginUsername, editTextLoginPassword;
    Button btnLogin;
    TextView tvRegister, tvLogin, tvHealth ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);
        editTextLoginUsername=findViewById(R.id.editTextLoginUsername);
        editTextLoginPassword=findViewById(R.id.editTextLoginPassword);
        btnLogin=findViewById(R.id.btnLogin);
        tvRegister=findViewById(R.id.tvRegister);
        tvHealth=findViewById(R.id.tvHealth);
        tvLogin=findViewById(R.id.tvLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username=editTextLoginUsername.getText().toString();
                String password=editTextLoginPassword.getText().toString();
                Database db=new Database(getApplicationContext(),"healthcare",null,1);
                if(username.isEmpty() || password.isEmpty())
                {
                    Toast.makeText(getApplicationContext(),"Fields are empty!",Toast.LENGTH_SHORT).show();
                }
                else {
                    if(db.login(username,password)==1)
                    {
                        Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_SHORT).show();
                        SharedPreferences sharedpreferences=getSharedPreferences("shared_prefs",Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor=sharedpreferences.edit();
                        editor.putString("username",username);
                        editor.apply();
                        startActivity(new Intent(LoginActivity.this,HomeActivity.class));
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "invalid username and password", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
tvRegister.setOnClickListener(new View.OnClickListener()
{
    @Override
    public void onClick(View view) {
        startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
    }

    });

    }
}